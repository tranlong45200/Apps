package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.language.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.data.Language
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.databinding.ItemLanguageBinding

class LanguageAdapter :
    ListAdapter<Language, LanguageAdapter.ViewHolder>(
        DIFF_CALLBACK
    ) {

    private var onItemSelected: (Int) -> Unit = {}

    fun setOnItemClickListener(onItemSelected: (Int) -> Unit) =
        apply {
            this.onItemSelected = onItemSelected
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemLanguageBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.onBindItem(getItem(position),position)
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int,
        payloads: MutableList<Any>
    ) {
        if (payloads.contains(PAYLOAD_SELECTED)) {
            holder.updateSelectedState(getItem(position))
        } else {
            super.onBindViewHolder(holder, position, payloads)
        }
    }

    companion object {
        private const val PAYLOAD_SELECTED = "PAYLOAD_SELECTED"

        private val DIFF_CALLBACK =
            object : DiffUtil.ItemCallback<Language>() {
                override fun areItemsTheSame(
                    oldItem: Language,
                    newItem: Language
                ): Boolean {
                    return oldItem.languageCode == newItem.languageCode
                }

                override fun areContentsTheSame(
                    oldItem: Language,
                    newItem: Language
                ): Boolean {
                    return oldItem == newItem
                }

                override fun getChangePayload(
                    oldItem: Language,
                    newItem:Language
                ): Any? {
                    return if (oldItem.isSelect != newItem.isSelect) {
                        PAYLOAD_SELECTED
                    } else {
                        super.getChangePayload(oldItem, newItem)
                    }
                }
            }
    }

    inner class ViewHolder(
        private val binding: ItemLanguageBinding,
    ) : RecyclerView.ViewHolder(binding.root) {

        fun onBindItem(item: Language, position: Int) {
            val context = binding.root.context
            binding.languageNameTxt.text = context.getString(item.languageNameStrId)
            binding.flagImg.setImageResource(item.languageIconDrawId)
            updateSelectedState(item)
            binding.root.setOnClickListener {
                onItemSelected(position)
            }
        }

        fun updateSelectedState(item: Language) {
            binding.checkbox.isSelected = item.isSelect
        }
    }
}