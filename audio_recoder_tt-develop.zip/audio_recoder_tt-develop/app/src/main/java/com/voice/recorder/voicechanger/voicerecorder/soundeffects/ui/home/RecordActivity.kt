package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home

import android.Manifest
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.View
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.MutableLiveData
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.GlobalApp
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.R
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.base.BindingActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.databinding.ActivityRecordBinding
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.dialog.CancelRecordDialog
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.dialog.PermissionDialog
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home.collection.MyFileActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.service.OnActionCallback
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.service.RecordService
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.ACTION_CLICK_CANCEL_NOTIFICATION
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.ACTION_CLICK_SAVE_NOTIFICATION
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.IS_FROM
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.KEY_ACTION_CLICK_NOTIFICATION
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.KEY_PATH
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Utils
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.fromHtml
import java.io.File

class RecordActivity : BindingActivity<ActivityRecordBinding>() {
    override fun getViewBinding(): ActivityRecordBinding {
        return ActivityRecordBinding.inflate(layoutInflater)
    }

    private val requestNotiPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->

        }

    private val requestNotiPermissionDialog =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (!isGranted) {
                showNotificationPermissionDialog()
            }
        }
    private val goToSettingNotificationLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.TIRAMISU) {
                checkNotificationAndroid13()
            }
        }
    private val mediaPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    }

    private val audioPermission = Manifest.permission.RECORD_AUDIO

    private val requestMediaPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { isGranted ->
        if (isGranted) {
            navigateToRecord()
        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, mediaPermissions)) {
                requestMediaPermission()
            } else {
                showPermissionDialog(Constants.MEDIA_PERMISSION)
            }
        }
    }

    private val mediaPermissionLauncher: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (checkSelfMediaPermission()) {
                navigateToRecord()
            } else {
                requestMediaPermission()
            }
        }

    private fun checkSelfMediaPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            mediaPermissions,
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestMediaPermission() {
        requestMediaPermissionLauncher.launch(mediaPermissions)
    }

    private val requestAudioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { isGranted ->
        if (isGranted) {
            if (checkSelfMediaPermission()) {
                navigateToRecord()
            } else {
                requestMediaPermission()
            }
        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(
                    this,
                    mediaPermissions,
                )
            ) {
                requestMediaPermission()
            } else {
                showPermissionDialog(Constants.AUDIO_PERMISSION)
            }
        }
    }

    private fun showPermissionDialog(typePermissionRequested: Int) {
        if (typePermissionRequested == Constants.MEDIA_PERMISSION) {
            PermissionDialog.newInstance(
                R.drawable.ic_media,
                getString(R.string.permission_media_title).fromHtml(),
                onGoToSetting = {
                    Utils.goToSettingApp(this, mediaPermissionLauncher)
                },
                cancelPermission = {},
            ).show(supportFragmentManager, PermissionDialog.TAG)
        }
        if (typePermissionRequested == Constants.AUDIO_PERMISSION) {
            PermissionDialog.newInstance(
                R.drawable.ic_mic,
                getString(R.string.permission_audio_title).fromHtml(),
                onGoToSetting = {
                    Utils.goToSettingApp(this, audioPermissionLauncher)
                },
                cancelPermission = {},
            ).show(supportFragmentManager, PermissionDialog.TAG)
        }
    }

    private fun checkSelfAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            audioPermission,
        ) == PackageManager.PERMISSION_GRANTED
    }

    private val audioPermissionLauncher: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (checkSelfAudioPermission()) {
                if (checkSelfMediaPermission()) {
                    navigateToRecord()
                } else {
                    requestMediaPermission()
                }
            } else {
                requestAudioPermission()
            }
        }

    private fun navigateToRecord() {
        if (!checkSelfAudioPermission()) {
            requestAudioPermission()
            return
        }
        if (!checkSelfMediaPermission()) {
            requestMediaPermission()
            return
        }
        executeStartRecord()
    }

    private fun requestAudioPermission() {
        requestAudioPermissionLauncher.launch(audioPermission)
    }

    private val cancelDialog by lazy {
        CancelRecordDialog(object : OnActionCallback {
            override fun callback(key: String, data: Any?) {
                if (key == Constants.KEY_DELETE) {
                    executeStopRecord(isCancel = true, isExitApp = false)
                    val file = recordingService?.file?.absolutePath?.let { File(it) }
                    file?.delete()
                    stopRecord(false)
                    binding.ivDeleteRecord.visibility = View.INVISIBLE
                    binding.ivStopRecord.visibility = View.INVISIBLE
                    binding.ivRecord.visibility = View.VISIBLE
                    binding.ivResume.visibility = View.INVISIBLE
                    binding.ivPlay.visibility = View.INVISIBLE
                    binding.txtTimeRecord.text = "00:00:00"
                }
            }
        })
    }


    private var seconds = 0
    var isRecording = false
        private set
    private var isPause = false

    private val intentService by lazy { Intent(this, RecordService::class.java) }

    private var recordingService: RecordService? = null
    private val recordServiceLiveData = MutableLiveData(false)

    private val connection: ServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            if (recordingService == null) {
                recordingService = (binder as RecordService.ServiceBinder).service
                recordServiceLiveData.postValue(true)
            }
            handleActionNotification(intent)
            intent = null
        }

        override fun onServiceDisconnected(name: ComponentName) {
            recordingService = null
        }
    }

    private fun executeStartRecord() {
        isRecording = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ContextCompat.startForegroundService(this, intentService)
        } else {
            startService(intentService)
        }
        bindService(intentService, connection, Context.BIND_AUTO_CREATE)
        isRecording = true
        binding.lavHTP.playAnimation()
        binding.ivDeleteRecord.visibility = View.VISIBLE
        binding.ivStopRecord.visibility = View.VISIBLE
        binding.ivRecord.visibility = View.INVISIBLE
        binding.ivResume.visibility = View.VISIBLE
        binding.ivPlay.visibility = View.INVISIBLE
        sendActionToService(Constants.ACTION_START_RECORDING)
        initBroadcastReceiver()
    }

    private fun sendActionToService(action: Int) {
        intentService.putExtra(RecordService.KEY_ACTION_SEND_ACTION_TO_SERVICE, action)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ContextCompat.startForegroundService(this, intentService)
        } else {
            startService(intentService)
        }
    }

    private fun handleActionNotification(intent: Intent?) {
        val action = intent?.getStringExtra(KEY_ACTION_CLICK_NOTIFICATION)
        if (action == ACTION_CLICK_CANCEL_NOTIFICATION) {
            executeDeleteFile()
        } else if (action == ACTION_CLICK_SAVE_NOTIFICATION) {
            executeStopRecord(isCancel = false, isExitApp = false)
        }
    }

    private fun executeResume(isPause: Boolean) {
        if (recordingService == null) {
            return
        }
        if (isPause) {
            recordingService?.resumeRecord()
            binding.lavHTP.playAnimation()
            binding.ivResume.visibility = View.VISIBLE
            binding.ivPlay.visibility = View.INVISIBLE
        } else {
            binding.ivResume.visibility = View.GONE
            binding.ivPlay.visibility = View.VISIBLE
            binding.lavHTP.cancelAnimation()
            kotlin.runCatching {
                recordingService?.pauseRecord()
            }
        }
        this.isPause = !isPause
    }

    private fun executeDeleteFile() {
        isRecording = false
        executeResume(false)
        cancelDialog.setCancelable(false)
        cancelDialog.show(
            supportFragmentManager.beginTransaction().remove(cancelDialog),
            CancelRecordDialog::class.java.name
        )
    }

    private fun executeStopRecord(isCancel: Boolean, isExitApp: Boolean) {
        binding.ivResume.setImageResource(R.drawable.ic_pause)
        isRecording = false
        isPause = false
        stopRecord(!isCancel)
        GlobalApp.isSaveAudioSuccess.observe(this) { isSave: Boolean ->
            if (isSave) {
                saveAudio()
                GlobalApp.isSaveAudioSuccess.value = false
            }
        }
        binding.lavHTP.cancelAnimation()
        stopService()
    }

    private fun stopService() {
        stopService(intentService)
    }

    private fun saveAudio() {
        isPause = false
        isRecording = false
        if (recordingService?.file == null) {
            Toast.makeText(this, R.string.file_has_not_save, Toast.LENGTH_SHORT).show()
            return
        }
        kotlin.runCatching {
            Toast.makeText(
                this,
                getString(R.string.audio_is_saved_in, recordingService?.file?.absolutePath),
                Toast.LENGTH_SHORT
            ).show()
            startActivity(Intent(this, PlayRecordActivity::class.java).apply {
                putExtra(IS_FROM, "RecordActivity")
                putExtra(KEY_PATH, recordingService?.file?.absolutePath)
            })
            finish()
        }
    }

    private fun stopRecord(isSave: Boolean) {
        recordingService?.stopRecording(isSave)
    }

    private val isServiceRunning: Boolean
        get() {
            val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            for (service in manager.getRunningServices(Int.MAX_VALUE)) {
                if (RecordService::class.java.name == service.service.className) {
                    return true
                }
            }
            return false
        }
    private val broadcastReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        @SuppressLint("SetTextI18n")
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.getIntExtra(RecordService.KEY_ACTION, 0)
            if (action == Constants.ACTION_UPDATE_TIME) {
                seconds = intent.getIntExtra(RecordService.KEY_RUNTIME, 0)
                binding.txtTimeRecord.text = Utils.formatTime((seconds * 1000).toLong(), true)
            }
            if (action == Constants.ACTION_GET_INFO_FOR_FRAGMENT_RECORDER) {
                isRecording = intent.getBooleanExtra(RecordService.KEY_IS_RECORDING, false)
                isPause = intent.getBooleanExtra(RecordService.KEY_IS_PAUSE, false)
                if (isRecording) {
                    if (isPause) {
                        binding.ivResume.visibility = View.INVISIBLE
                        binding.ivPlay.visibility = View.VISIBLE
                        isRecording = false
                        binding.lavHTP.pauseAnimation()
                        seconds = intent.getIntExtra(RecordService.KEY_RUNTIME, 0)
                        binding.txtTimeRecord.text =
                            Utils.formatTime((seconds * 1000).toLong(), true)
                    } else {
                        isRecording = true
                        binding.lavHTP.playAnimation()
                        binding.ivPlay.visibility = View.INVISIBLE
                        binding.ivResume.visibility = View.VISIBLE
                    }
                }
            }
            if (action == Constants.ACTION_START_RECORDING) {
                recordServiceLiveData.observe(this@RecordActivity) { isAvailable: Boolean ->
                    if (isAvailable) {
                        try {
                            isRecording = true
                            isPause = false
                            recordingService?.startRecord(object : OnActionCallback {
                                override fun callback(key: String, data: Any?) {
                                    if (key == Constants.KEY_NAME_FILE) {

                                    } else if (key == Constants.KEY_ERROR) {
                                        Toast.makeText(
                                            context,
                                            context.getString(R.string.not_record_try_agin),
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        executeStopRecord(false, false)
                                    }
                                }

                            })
                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(
                                context,
                                context.getString(R.string.try_again_later),
                                Toast.LENGTH_SHORT
                            ).show()
                            isRecording = false
                        }
                    }
                }
            }
        }
    }
    private val receiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(myContext: Context, intent: Intent) {
            if (intent.action == RecordService.ACTION_STOP) {
                executeStopRecord(false, false)
            }
        }
    }

    private fun initBroadcastReceiver() {
        val intentFilterControl = IntentFilter()
        intentFilterControl.addAction(RecordService.ACTION_STOP)
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        registerReceiver(receiver, intentFilterControl)
    }

    override fun updateUI(savedInstanceState: Bundle?) {
        LocalBroadcastManager.getInstance(this).registerReceiver(
            broadcastReceiver, IntentFilter(RecordService.KEY_ACTION_SEND_ACTION_TO_FRAGMENT)
        )
        checkNotificationAndroid13()
        binding.ivResume.visibility = View.INVISIBLE
        binding.ivPlay.visibility = View.INVISIBLE
        binding.ivRecord.visibility = View.VISIBLE
        binding.ivList.visibility = View.VISIBLE
        binding.ivRecord.setOnClickListener {
            navigateToRecord()
        }
        binding.ivResume.setOnClickListener {
            isRecording = false
            executeResume(isPause)
        }
        binding.ivPlay.setOnClickListener {
            isRecording = true
            executeResume(isPause)
        }
        binding.ivDeleteRecord.setOnClickListener {
            executeDeleteFile()
        }
        binding.ivStopRecord.setOnClickListener {
            executeStopRecord(isCancel = false, isExitApp = false)
        }
        binding.ivList.setOnClickListener {
            if (isRecording) {
                return@setOnClickListener
            }
            startActivity(Intent(this, MyFileActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        bindService(
            intentService, connection, Context.BIND_AUTO_CREATE
        )
    }

    override fun onPause() {
        super.onPause()
        kotlin.runCatching {
            unbindService(connection)
        }
    }

    override fun onDestroy() {
        if (recordingService != null && (!isRecording && !isPause || seconds == 0)) {
            try {
                recordingService?.stopSelf()
            } catch (ignored: Exception) {
            }
        }
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver)
        super.onDestroy()
    }

    private fun showNotificationPermissionDialog() {
        PermissionDialog.newInstance(
            iconHeader = R.drawable.ic_notification,
            title = getString(R.string.permission_noti_title).fromHtml(),
            onGoToSetting = {
                Utils.goToSettingApp(
                    this, goToSettingNotificationLauncher
                )
            },
            cancelPermission = {
            }, clickOutSide = true
        ).show(this.supportFragmentManager)
    }

    private fun checkNotificationAndroid13(isDialog: Boolean = false) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS,
                ) == PackageManager.PERMISSION_DENIED
            ) {
                if (isDialog) {
                    requestNotiPermissionDialog.launch(
                        Manifest.permission.POST_NOTIFICATIONS,
                    )
                } else {
                    requestNotiPermission.launch(
                        Manifest.permission.POST_NOTIFICATIONS,
                    )
                }
            }
        }
    }
}