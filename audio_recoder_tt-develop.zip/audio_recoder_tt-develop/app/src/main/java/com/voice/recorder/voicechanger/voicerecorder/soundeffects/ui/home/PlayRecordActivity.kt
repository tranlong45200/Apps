package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home

import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.R
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.base.BindingActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.data.AudioModel
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.databinding.ActivityRecordBinding
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants
import java.util.concurrent.TimeUnit


class PlayRecordActivity : BindingActivity<ActivityRecordBinding>() {
    override fun getViewBinding(): ActivityRecordBinding {
        return ActivityRecordBinding.inflate(layoutInflater)
    }

    private var currentTime = 0L
    private var handle: Handler? = null
    private val updateSongTime: Runnable = object : Runnable {
        override fun run() {
            currentTime = mediaPlayer?.currentPosition?.toLong() ?: 0L
            binding.txtTimeRecord.setText(
                String.format(
                    "%d:%d",
                    TimeUnit.MILLISECONDS.toMinutes(currentTime),
                    TimeUnit.MILLISECONDS.toSeconds(currentTime) - TimeUnit.MINUTES.toSeconds(
                        TimeUnit.MILLISECONDS.toMinutes(currentTime)
                    )
                )
            )
            handle?.postDelayed(this, 100)
        }
    }
    private var mediaPlayer: MediaPlayer? = null
    override fun updateUI(savedInstanceState: Bundle?) {
        handle = Handler(Looper.getMainLooper())
        handle?.postDelayed(updateSongTime, 100)
        binding.ivDeleteRecord.visibility = View.INVISIBLE
        binding.ivRecord.visibility = View.INVISIBLE
        binding.ivStopRecord.visibility = View.INVISIBLE
        binding.ivBack.visibility = View.VISIBLE
        binding.ivList.visibility = View.INVISIBLE
        binding.ivResume.visibility = View.INVISIBLE
        binding.ivPlay.visibility = View.VISIBLE
        loadMedia()

        binding.ivBack.setOnClickListener {
            stopMedia()
            startActivity(Intent(this, RecordActivity::class.java))
            finish()
        }
        binding.ivPlay.setOnClickListener {
            mediaPlayer?.let {
                with(it) {
                    if (isPlaying) {
                        pause()
                        binding.ivPlay.setImageResource(R.drawable.ic_play)
                    } else {
                        handle?.postDelayed(updateSongTime, 100)
                        binding.ivPlay.setImageResource(R.drawable.ic_pause)
                        start()
                    }
                }
            }
        }
    }

    private fun stopMedia() {
        mediaPlayer?.let {
            it.stop()
            it.release()
            mediaPlayer = null
        }
    }

    override fun onBackPressed() {
        stopMedia()
        super.onBackPressed()
    }

    override fun onPause() {
        mediaPlayer?.let {
            with(it) {
                if (isPlaying) {
                    pause()
                    binding.ivPlay.visibility = View.VISIBLE
                    binding.ivResume.visibility = View.INVISIBLE
                }
            }
        }
        super.onPause()
    }

    private fun loadMedia() {
        var path = ""
        intent.getStringExtra(Constants.KEY_PATH)?.let {
            path = it
        } ?: run {
            intent.getStringExtra(Constants.IS_FROM)?.let {
                if (it == "MyFileActivity") {
                    val audio = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getSerializableExtra(Constants.AUDIO_MODEL, AudioModel::class.java)
                    } else {
                        intent.getSerializableExtra(Constants.AUDIO_MODEL)
                    }
                    kotlin.runCatching {
                        path = (audio as AudioModel).path
                    }
                }
            }
        }
        if (path.isNotEmpty()) {
            mediaPlayer = MediaPlayer()
            runCatching {
                mediaPlayer?.setDataSource(path)
                mediaPlayer?.prepare()
                mediaPlayer?.start()
                binding.ivPlay.setImageResource(R.drawable.ic_pause)
            }
        }
    }
}