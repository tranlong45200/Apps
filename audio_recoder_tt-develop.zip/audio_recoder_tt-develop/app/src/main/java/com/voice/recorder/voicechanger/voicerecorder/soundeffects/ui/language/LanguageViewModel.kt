package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.language

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.data.ConfigPreferences
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.getListDefaultLanguage

class LanguageViewModel(private val configPreferences: ConfigPreferences) : ViewModel() {

    private val _listLanguage = MutableLiveData(getListDefaultLanguage().apply {
        this.findLast { it.languageCode == configPreferences.languageCode }?.isSelect = true
    })

    val listLanguage = _listLanguage

    fun selectLanguage(position: Int) {
        _listLanguage.value?.mapIndexed { index, item ->
            item.isSelect = index == position
        }.apply {
            _listLanguage.value = _listLanguage.value?.let { ArrayList(it) }
        }
    }

}