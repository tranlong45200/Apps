package com.voice.recorder.voicechanger.voicerecorder.soundeffects.util

import android.os.Environment

object Constants {

    const val MEDIA_PERMISSION = 1001
    const val AUDIO_PERMISSION = 1410
    const val IS_FROM: String = "IS_FROM"
    const val AUDIO_MODEL: String = "AUDIO_MODEL"
    const val KEY_PATH: String = "KEY_PATH"
    const val KEY_DELETE: String = "KEY_DELETE"
    var BASE_PATH: String =
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).path + "/MyRecords"
    const val AUDIO_EXTENSION = "mp3"
    const val DEFAULT_NAME = "My_record_"
    const val KEY_NAME_FILE: String = "KEY_NAME_FILE"
    const val KEY_ERROR: String = "KEY_ERROR"
    const val ACTION_CLICK_RECORD_NOTIFICATION = "ACTION_CLICK_RECORD"
    const val ACTION_CLICK_PLAY_PAUSE_NOTIFICATION = "ACTION_CLICK_PLAY_PAUSE"
    const val ACTION_CLICK_SAVE_NOTIFICATION = "ACTION_CLICK_SAVE"
    const val ACTION_CLICK_CANCEL_NOTIFICATION = "ACTION_CLICK_CANCEL"
    const val KEY_ACTION_CLICK_NOTIFICATION = "KEY_ACTION_CLICK_NOTIFICATION"
    const val ACTION_START_RECORDING: Int = 3
    const val ACTION_GET_INFO_FOR_FRAGMENT_RECORDER: Int = 2
    const val ACTION_UPDATE_TIME: Int = 1

}