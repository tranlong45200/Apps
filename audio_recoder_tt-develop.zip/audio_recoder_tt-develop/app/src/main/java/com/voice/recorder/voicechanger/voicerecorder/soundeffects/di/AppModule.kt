package com.voice.recorder.voicechanger.voicerecorder.soundeffects.di

import com.voice.recorder.voicechanger.voicerecorder.soundeffects.data.ConfigPreferences
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.language.LanguageViewModel
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.splash.SplashViewModel
import org.koin.android.ext.koin.androidApplication
import org.koin.dsl.module

val viewModelModule = module {
    single { LanguageViewModel(get()) }
    single { SplashViewModel(get()) }
}

val sharedPreferencesModule = module {
    single {
        ConfigPreferences(androidApplication())
    }
}