package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.splash

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.language.LanguageActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.base.BindingActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.data.ConfigPreferences
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.databinding.ActivitySplashBinding
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home.MainActivity
import org.koin.android.ext.android.inject

@SuppressLint("CustomSplashScreen")
class SplashActivity : BindingActivity<ActivitySplashBinding>() {
    private val configPreferences: ConfigPreferences by inject()

    private val viewModel: SplashViewModel by inject()
    private fun navigateNextScreen() {
        if (configPreferences.isFirstOpen == true)
            startActivity(Intent(this@SplashActivity, LanguageActivity::class.java))
        else
            startActivity(Intent(this@SplashActivity, MainActivity::class.java))
        finish()
    }

    override fun getViewBinding() = ActivitySplashBinding.inflate(layoutInflater)

    override fun updateUI(savedInstanceState: Bundle?) {
        viewModel.dataIsFetching.observe(this) {
            if (it) navigateNextScreen()
        }
    }

}