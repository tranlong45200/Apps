package com.voice.recorder.voicechanger.voicerecorder.soundeffects.dialog

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.InsetDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.Window
import androidx.annotation.DrawableRes
import androidx.fragment.app.DialogFragment
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.R
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.databinding.DialogPermissionBinding

class PermissionDialog : DialogFragment(R.layout.dialog_permission) {
    private var iconHeaderRes: Int? = null
    private var title: CharSequence = ""
    private var onGoToSetting: (() -> Unit)? = null
    private var cancelPermission: (() -> Unit)? = null
    private var clickOutSideForDissmis = false
    private lateinit var binding: DialogPermissionBinding

    companion object {
        const val TAG = "permission_dialog"
        fun newInstance(
            @DrawableRes iconHeader: Int,
            title: CharSequence,
            onGoToSetting: (() -> Unit),
            cancelPermission: (() -> Unit),
            clickOutSide: Boolean = false,
        ): PermissionDialog {
            return PermissionDialog().apply {
                this.iconHeaderRes = iconHeader
                this.title = title
                this.onGoToSetting = onGoToSetting
                this.cancelPermission = cancelPermission
                this.clickOutSideForDissmis = clickOutSide
            }
        }
    }

    fun show(fragmentManager: androidx.fragment.app.FragmentManager) {
        if (fragmentManager.findFragmentByTag(TAG) == null) {
            show(fragmentManager, TAG)
        }
    }

    init {
        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = DialogPermissionBinding.bind(view)
        setupEvent()
        dialog?.setCanceledOnTouchOutside(clickOutSideForDissmis)
        dialog?.window?.let {
            it.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            it.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val back = ColorDrawable(Color.TRANSPARENT)
        val margin = context?.resources?.getDimensionPixelSize(com.intuit.sdp.R.dimen._30sdp) ?: 0
        dialog?.window?.setBackgroundDrawable(InsetDrawable(back, margin, 0, margin, 0))
    }

    private fun setupEvent() {
        iconHeaderRes?.let {
            binding.imgPermission.setImageResource(it)
        }
        binding.txtTitle.text = title
        binding.txtAllow.setOnClickListener {
            onGoToSetting?.invoke()
            dismissAllowingStateLoss()
        }
        binding.txtDontAllow.setOnClickListener {
            cancelPermission?.invoke()
            dismissAllowingStateLoss()
        }
    }
}
