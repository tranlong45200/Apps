package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home.collection

import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.lifecycle.MutableLiveData
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.GlobalApp
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.base.BaseViewModel
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.data.AudioModel
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.BASE_PATH
import java.io.File

class MyFileViewModel : BaseViewModel() {

    private var audioFileLiveData: MutableLiveData<List<AudioModel>> = MutableLiveData()
    var audioFiles = audioFileLiveData.toLiveData()
    fun getAllAudioFilesFromDirectory(){
        val audioFiles = mutableListOf<String>()
        val audioFilesModels = mutableListOf<AudioModel>()
        val directory = File(BASE_PATH)
        if (directory.exists() && directory.isDirectory) {
            getAudioFilesRecursively(directory, audioFiles)
        }
        audioFiles.forEach {
            val audioModel = AudioModel(
                System.currentTimeMillis(),
                if (it.isEmpty()) {
                    System.currentTimeMillis().toString()
                } else {
                    getNameFromPath(it)
                },
                getMediaDuration(it),
                it,
            )
            audioFilesModels.add(audioModel)
        }
        audioFileLiveData.postValue(audioFilesModels)
    }

    private fun getAudioFilesRecursively(dir: File, audioFiles: MutableList<String>) {
        val files = dir.listFiles()

        files?.forEach { file ->
            if (file.isDirectory) {
                getAudioFilesRecursively(file, audioFiles)
            } else if (file.isFile && file.extension in listOf(
                    "mp3",
                    "wav",
                    "m4a",
                    "ogg",
                    "flac"
                )
            ) {
                audioFiles.add(file.absolutePath)
            }
        }
    }

    private fun getMediaDuration(path: String): Long {
        val file = File(path)
        if (!file.exists()) return 0
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(GlobalApp.appContext, Uri.parse(path))
        val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
        retriever.release()
        return duration?.toLongOrNull() ?: 0
    }

    private fun getNameFromPath(path: String): String {
        return File(path).name
    }
}