package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.onboarding

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.base.projectbasebasic.ui.onboarding.OnboardingAdapter
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.R
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.base.BindingActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.databinding.ActivityOnaboardingBinding
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.onboarding.fragment.OnboardingFragmentItem

class OnboardingActivity : BindingActivity<ActivityOnaboardingBinding>() {

    companion object {
        const val TAG = "TAG"
        const val ONBOARDING_1 = "ONBOARDING_1"
        const val ONBOARDING_2 = "ONBOARDING_2"
        const val ONBOARDING_3 = "ONBOARDING_3"
        const val ONBOARDING_FULL_SCR1 = "ONBOARDING_FULL_SCR1"
        const val ONBOARDING_FULL_SCR2 = "ONBOARDING_FULL_SCR2"
    }

    override val isLightTheme: Boolean
        get() = true

    private val fragmentsOnboarding = arrayListOf<Fragment>(
        OnboardingFragmentItem.newInstance(
            ONBOARDING_1,
            R.drawable.background_ob1,
            null,
            R.string.onboarding_title_page_1,
            idNative = "BuildConfig.native_onboaring1",
            isShowNative = false,
            idNative2Floor = "BuildConfig.native_onboaring1_2floor",
            isShowNative2Floor = true
        ),
        OnboardingFragmentItem.newInstance(
            ONBOARDING_2,
            R.drawable.background_ob2,
            null,
            R.string.onboarding_title_page_2,
            idNative = "BuildConfig.native_onboaring2",
            isShowNative = false,
            idNative2Floor = "",
            isShowNative2Floor = false
        ),
        OnboardingFragmentItem.newInstance(
            ONBOARDING_3,
            R.drawable.background_ob3,
            null,
            R.string.onboarding_title_page_3,
            idNative = "BuildConfig.native_onboaring3",
            isShowNative = false,
            idNative2Floor = "",
            isShowNative2Floor = false
        )
    )
    private val onboardingAdapter by lazy {
        OnboardingAdapter(
            this
        )
    }

    fun removeFragment(tag: String) {
        when (tag) {
            ONBOARDING_FULL_SCR1 -> {
                onboardingAdapter.removeFragment(1)
                fragmentsOnboarding.removeAt(1)
            }

            ONBOARDING_FULL_SCR2 -> {
                onboardingAdapter.removeFragment(fragmentsOnboarding.size - 2)
                fragmentsOnboarding.removeAt(fragmentsOnboarding.size - 2)
            }
        }
    }

    fun nextFragment() {
        binding.onboardingViewPager.currentItem =
            binding.onboardingViewPager.currentItem + 1
    }

    override fun getViewBinding() = ActivityOnaboardingBinding.inflate(layoutInflater)

    override fun updateUI(savedInstanceState: Bundle?) {
        onboardingAdapter.addListFragment(fragmentsOnboarding)
        binding.onboardingViewPager.adapter = onboardingAdapter
        binding.onboardingViewPager.registerOnPageChangeCallback(object :
            ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
            }
        })
        binding.onboardingViewPager.offscreenPageLimit = 5
    }
}