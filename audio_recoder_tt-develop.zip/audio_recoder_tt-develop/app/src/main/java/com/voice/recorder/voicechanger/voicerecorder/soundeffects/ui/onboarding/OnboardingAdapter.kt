package com.base.projectbasebasic.ui.onboarding

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class OnboardingAdapter(
    fragment: FragmentActivity
) : FragmentStateAdapter(fragment) {
    private var fragments: ArrayList<Fragment> = arrayListOf()
    override fun getItemCount(): Int {
        return fragments.size
    }

    override fun getItemId(position: Int): Long {
        return fragments[position].hashCode().toLong()
    }

    override fun containsItem(itemId: Long): Boolean {
        return fragments.map { it.hashCode().toLong() }.toMutableList().contains(itemId)
    }

    override fun createFragment(position: Int): Fragment {
        return if (position < fragments.size) fragments[position]
        else fragments[0]
    }

    fun addListFragment(fragments: ArrayList<Fragment>) {
        this.fragments.clear()
        this.fragments.addAll(fragments)
        notifyDataSetChanged()
    }

    fun removeFragment(position: Int) {
        fragments.removeAt(position)
        notifyItemRemoved(position)
    }
}