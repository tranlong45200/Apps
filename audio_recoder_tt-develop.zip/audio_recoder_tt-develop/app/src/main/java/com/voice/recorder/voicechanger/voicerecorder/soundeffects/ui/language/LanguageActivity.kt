package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.language

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.os.Bundle
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.language.adapter.LanguageAdapter
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.onboarding.OnboardingActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.base.BindingActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.databinding.ActivityLanguageBinding
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.getListDefaultLanguage
import org.koin.android.ext.android.inject

class LanguageActivity : BindingActivity<ActivityLanguageBinding>() {
    private val adapter: LanguageAdapter by lazy {
        LanguageAdapter()
    }

    private val viewModel: LanguageViewModel by inject()

    @SuppressLint("NotifyDataSetChanged")
    fun listener() {
        viewModel.listLanguage.observe(this) {
            adapter.submitList(it)
            adapter.notifyDataSetChanged()
        }
        adapter.setOnItemClickListener {
            viewModel.selectLanguage(it)
            if (CURRENT_SCREEN_LFO == LFO1) {
                val intent = Intent(this, LanguageActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                startActivity(intent)
                finishAffinity()
            }
            CURRENT_SCREEN_LFO = LFO2
        }
    }

    companion object {
        const val LFO1 = "LFO1"
        const val LFO2 = "LFO2"
        var CURRENT_SCREEN_LFO = LFO1
    }

    override fun getViewBinding() = ActivityLanguageBinding.inflate(layoutInflater)
    override fun updateUI(savedInstanceState: Bundle?) {
        binding.rvLanguage.adapter = adapter
        adapter.submitList(getListDefaultLanguage())
        when (CURRENT_SCREEN_LFO) {
            LFO1 -> {
                val color = Color.parseColor("#E4E4E4")
                binding.imgChoose.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
            }

            else -> {
                val color = Color.parseColor("#000000")
                binding.imgChoose.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
            }
        }

        binding.imgChoose.setOnClickListener {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finishAffinity()
        }

        listener()
    }
}