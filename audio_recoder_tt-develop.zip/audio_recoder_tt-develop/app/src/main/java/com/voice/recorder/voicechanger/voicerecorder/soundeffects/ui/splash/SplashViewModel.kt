package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.splash

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.data.ConfigPreferences
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings

class SplashViewModel(private val configPreferences: ConfigPreferences) : ViewModel() {

    var dataIsFetching = MutableLiveData<Boolean>(false)

    init {
        setupRemoteConfig {
            dataIsFetching.value = true
        }
    }

    private fun setupRemoteConfig(handleRemoteConfig: () -> Unit) {
        val firebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
        val configSettings =
            FirebaseRemoteConfigSettings.Builder().setMinimumFetchIntervalInSeconds(3600).build()
        firebaseRemoteConfig.setConfigSettingsAsync(configSettings)
        firebaseRemoteConfig.fetchAndActivate()
            .addOnCompleteListener { configSettingsTask ->
                if (configSettingsTask.isSuccessful) {
                    val updated = configSettingsTask.result
                    if (updated) {
                        Log.e(
                            "TAG",
                            "setupRemoteConfig: ${firebaseRemoteConfig.getBoolean(ConfigPreferences.BANNER_SPLASH)}",
                        )
                        configPreferences.isShowBannerSplash =
                            firebaseRemoteConfig.getBoolean(ConfigPreferences.BANNER_SPLASH)
                    }
                }
                handleRemoteConfig()
            }.addOnFailureListener {
                handleRemoteConfig()
            }.addOnSuccessListener {
                handleRemoteConfig()
            }
    }

}