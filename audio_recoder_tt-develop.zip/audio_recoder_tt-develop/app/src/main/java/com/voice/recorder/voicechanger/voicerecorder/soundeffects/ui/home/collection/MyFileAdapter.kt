package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home.collection

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.data.AudioModel
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.databinding.LayoutItemMyFileBinding
import java.util.concurrent.TimeUnit
import kotlin.math.min

class MyFileAdapter(val onClick: (AudioModel) -> Unit) :
    RecyclerView.Adapter<MyFileAdapter.MyFileViewHolder>() {

    private val listFile = mutableListOf<AudioModel>()

    inner class MyFileViewHolder(private val itemBinding: LayoutItemMyFileBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {

        fun bindView(position: Int) {
            val item = listFile[position]
            itemBinding.tvName.text = item.name
            val minute = TimeUnit.MILLISECONDS.toMinutes(item.duration)
            val second = TimeUnit.MILLISECONDS.toSeconds(item.duration)
            itemBinding.tvDuration.text =
                String.format(
                    "%s:%s", if (minute == 0L) {
                        "00"
                    } else {
                        minute
                    },
                    if (second < 10) {
                        "0$second"
                    } else {
                        second
                    }
                )
            itemBinding.root.setOnClickListener {
                onClick.invoke(item)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyFileViewHolder {
        val itemBinding =
            LayoutItemMyFileBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyFileViewHolder(itemBinding)
    }

    override fun getItemCount(): Int = listFile.size

    override fun onBindViewHolder(holder: MyFileViewHolder, position: Int) {
        holder.bindView(position)
    }

    @SuppressLint("NotifyDataSetChanged")
    fun submitList(newList: List<AudioModel>) {
        listFile.clear()
        listFile.addAll(newList)
        notifyDataSetChanged()
    }
}
