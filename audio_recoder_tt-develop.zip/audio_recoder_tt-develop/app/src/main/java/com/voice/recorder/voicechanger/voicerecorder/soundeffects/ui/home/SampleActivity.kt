package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.splash.SplashActivity

class SampleActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val intent = Intent(this, SplashActivity::class.java)
        startActivity(intent)
        finish()
    }
}
