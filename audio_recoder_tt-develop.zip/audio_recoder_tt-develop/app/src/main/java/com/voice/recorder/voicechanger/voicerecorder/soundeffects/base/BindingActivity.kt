package com.voice.recorder.voicechanger.voicerecorder.soundeffects.base

import android.os.Bundle
import android.view.View
import androidx.viewbinding.ViewBinding

abstract class BindingActivity<T : ViewBinding> : BaseActivity() {
    companion object {
        private const val TAG = "BaseActivityBinding"
    }

    protected lateinit var binding: T
        private set

    final override fun createContentView(savedInstanceState: Bundle?): View {
        binding = getViewBinding()
        return binding.root
    }

    abstract fun getViewBinding(): T
}
