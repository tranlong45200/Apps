package com.voice.recorder.voicechanger.voicerecorder.soundeffects.util

import com.voice.recorder.voicechanger.voicerecorder.soundeffects.R
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.data.Language

fun getListDefaultLanguage(): ArrayList<Language> = arrayListOf(
    Language("fr", R.string.setting_fr, R.drawable.ic_fr_new),
    Language("en", R.string.setting_en, R.drawable.ic_en_new),
    Language("hi", R.string.setting_hi, R.drawable.ic_hi_new),
    Language("es", R.string.setting_es, R.drawable.ic_es_new),
    Language("zh", R.string.setting_zh, R.drawable.ic_zh),
    Language("pt", R.string.setting_pt, R.drawable.ic_pt_new),
    Language("ru", R.string.setting_ru, R.drawable.ic_ru)
)