package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home.collection

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.core.view.isVisible
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.base.BindingActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.databinding.ActivityMyFilesBinding
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home.PlayRecordActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.AUDIO_MODEL
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.IS_FROM

class MyFileActivity : BindingActivity<ActivityMyFilesBinding>() {
    companion object {
        const val TAG = "MyFileActivity"
    }

    private val adapter: MyFileAdapter by lazy {
        MyFileAdapter { audio ->
            val intent = Intent(this, PlayRecordActivity::class.java).apply {
                putExtra(IS_FROM, "MyFileActivity")
                putExtra(AUDIO_MODEL, audio)
            }
            startActivity(intent)
        }
    }

    override fun getViewBinding(): ActivityMyFilesBinding {
        return ActivityMyFilesBinding.inflate(layoutInflater)
    }

    private val viewmodel: MyFileViewModel by viewModels()
    override fun updateUI(savedInstanceState: Bundle?) {
        viewmodel.getAllAudioFilesFromDirectory()
        binding.rvMyFiles.adapter = adapter
        observeData()
        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    private fun observeData() {
        viewmodel.audioFiles.observe(this) {
            Log.i(TAG, "observeData: $it")
            adapter.submitList(it)
            binding.txtNoData.isVisible = it.isEmpty()
        }
    }
}