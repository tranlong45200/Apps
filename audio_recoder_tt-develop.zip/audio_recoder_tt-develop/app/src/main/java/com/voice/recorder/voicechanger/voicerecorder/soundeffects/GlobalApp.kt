package com.voice.recorder.voicechanger.voicerecorder.soundeffects

import android.app.Application
import androidx.lifecycle.MutableLiveData
import com.google.firebase.FirebaseApp
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.di.sharedPreferencesModule
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.di.viewModelModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.GlobalContext

class GlobalApp : Application() {
    companion object {
        var isSaveAudioSuccess: MutableLiveData<Boolean> = MutableLiveData(false)
        var appContext: GlobalApp? = null
    }

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        appContext = this

        GlobalContext.startKoin {
            androidContext(this@GlobalApp)
            modules(
                viewModelModule,
                sharedPreferencesModule
            )
        }
    }
}

