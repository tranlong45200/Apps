package com.voice.recorder.voicechanger.voicerecorder.soundeffects.data

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class Language(
    val languageCode: String,
    @StringRes val languageNameStrId: Int,
    @DrawableRes val languageIconDrawId: Int,
    var isSelect: Boolean = false
)