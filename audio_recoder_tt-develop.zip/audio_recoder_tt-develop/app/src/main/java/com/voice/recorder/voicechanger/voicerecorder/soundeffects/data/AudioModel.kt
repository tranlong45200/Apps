package com.voice.recorder.voicechanger.voicerecorder.soundeffects.data

import java.io.Serializable

data class AudioModel(
    val id: Long,
    val name: String,
    var duration: Long = 0,
    val path: String = "",
) : Serializable
