package com.voice.recorder.voicechanger.voicerecorder.soundeffects.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import androidx.fragment.app.DialogFragment
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.databinding.DialogCancelRecordBinding
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.service.OnActionCallback
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants

class CancelRecordDialog(var callback: OnActionCallback) : DialogFragment() {
    private lateinit var binding: DialogCancelRecordBinding
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        return dialog
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DialogCancelRecordBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.txtCancel.setOnClickListener {
            dismiss()
        }
        binding.txtExit.setOnClickListener {
            callback.callback(Constants.KEY_DELETE, null)
            dismiss()
        }
    }
}