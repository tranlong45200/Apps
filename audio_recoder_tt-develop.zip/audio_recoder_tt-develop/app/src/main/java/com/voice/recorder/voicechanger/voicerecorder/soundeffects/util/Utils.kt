package com.voice.recorder.voicechanger.voicerecorder.soundeffects.util

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.result.ActivityResultLauncher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone

object Utils {
    fun goToSettingApp(activity: Activity, launcher: ActivityResultLauncher<Intent>) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            intent.setData(
                Uri.fromParts(
                    "package",
                    activity.packageName,
                    null
                )
            )
            launcher.launch(intent)
        } catch (ex: Exception) {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            launcher.launch(intent)
        }
    }

    fun formatTime(duration: Long, isHour: Boolean): String {
        var formatter = SimpleDateFormat("HH:mm:ss")
        if (!isHour) {
            formatter = SimpleDateFormat("mm:ss")
        }
        val date = Date(duration)
        formatter.timeZone = TimeZone.getTimeZone("UTC")
        return formatter.format(date)
    }
}