package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.R
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.base.BindingActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.databinding.ActivityMainBinding
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home.collection.MyFileActivity

class MainActivity : BindingActivity<ActivityMainBinding>() {
    override fun getViewBinding() = ActivityMainBinding.inflate(layoutInflater)

    override fun updateUI(savedInstanceState: Bundle?) {
        Log.e("TAG", "updateUI: ", )
        listener()
    }

    private fun listener() {
        binding.lnRecorder.setOnClickListener {
            Log.e("TAG", "RecordActivity: ", )
            startActivity(Intent(this, RecordActivity::class.java))
        }

        binding.lnMyRecording.setOnClickListener {
            Log.e("TAG", "lnMyRecording: ", )
            startActivity(Intent(this, MyFileActivity::class.java))
        }

        binding.lnSpeechToText.setOnClickListener {
            Toast.makeText(this, getString(R.string.feature_coming_soon), Toast.LENGTH_SHORT).show()
        }

        binding.lnSoundEffect.setOnClickListener {
            Toast.makeText(this, getString(R.string.feature_coming_soon), Toast.LENGTH_SHORT).show()
        }
    }

}