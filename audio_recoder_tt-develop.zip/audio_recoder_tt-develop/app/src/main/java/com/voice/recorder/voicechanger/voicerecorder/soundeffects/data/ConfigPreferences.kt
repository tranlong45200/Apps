package com.voice.recorder.voicechanger.voicerecorder.soundeffects.data

import android.content.Context
import com.base.projectbasebasic.data.Preferences

class ConfigPreferences(context: Context) : Preferences(context, "ConfigPreferences") {
    companion object {
        //config app
        private const val LANGUAGE_CODE = "LANGUAGE_CODE"
        private const val FIRST_OPEN = "FIRST_OPEN"

        //config ads
        const val BANNER_SPLASH = "banner_splash"
    }

    var isFirstOpen by booleanPref(FIRST_OPEN, true)
    var isShowBannerSplash by booleanPref(BANNER_SPLASH, true)
    var languageCode by stringPref(LANGUAGE_CODE, "en")

}
