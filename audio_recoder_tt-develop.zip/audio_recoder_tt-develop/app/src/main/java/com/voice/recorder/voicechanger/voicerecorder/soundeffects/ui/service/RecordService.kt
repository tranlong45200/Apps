package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.MediaRecorder
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.View
import android.widget.RemoteViews
import androidx.annotation.IntDef
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.GlobalApp
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.R
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home.RecordActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home.SampleActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.splash.SplashActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.ACTION_CLICK_CANCEL_NOTIFICATION
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.ACTION_CLICK_PLAY_PAUSE_NOTIFICATION
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.ACTION_CLICK_RECORD_NOTIFICATION
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.ACTION_CLICK_SAVE_NOTIFICATION
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.ACTION_UPDATE_TIME
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.AUDIO_EXTENSION
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.BASE_PATH
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.DEFAULT_NAME
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.KEY_ACTION_CLICK_NOTIFICATION
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.KEY_ERROR
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.util.Constants.KEY_NAME_FILE
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Timer
import java.util.TimerTask

class RecordService : Service() {
    companion object {

        const val NOTIFICATION_CHANNEL_DEFAULT = "Audio Notification Default"
        const val NOTIFICATION_CHANNEL = "Audio Notification"
        const val NOTIFICATION_RECORD_CHANNEL_ID = "channel_id"
        val ACTION_STOP: String = "ACTION_STOP"
        const val ACTION_GET_INFO_FOR_FRAGMENT_RECORDER: Int = 2
        const val ACTION_START_RECORDING: Int = 3
        val KEY_ACTION_SEND_ACTION_TO_FRAGMENT: String = "send_action_to_recorder_fragment"
        val KEY_RUNTIME: String = "run_time"
        val KEY_ACTION: String = "action"
        val KEY_IS_RECORDING: String = "is_recording"
        val KEY_IS_PAUSE: String = "is_Pause"
        val KEY_FILE_NAME: String = "file_name"
        val KEY_DATE: String = "date"
        val KEY_ACTION_SEND_ACTION_TO_SERVICE: String = "action_to_service"
        const val NOTIFICATION_RECORDING_ID = 1001
        const val DEFAULT_RATE = 48
        const val DEFAULT_BIT_RATE = 128

    }

    var file: File? = null
    private val mTimerFormat = SimpleDateFormat("mm:ss", Locale.getDefault())

    private var recorder: MediaRecorder? = null
    private var mElapsedSeconds = 0
    private var mTimer: Timer? = null
    private var mIncrementTimerTask: TimerTask? = null
    private val binder: IBinder = ServiceBinder()


    var isRecording = false

    inner class ServiceBinder : Binder() {
        val service: RecordService
            get() = this@RecordService
    }


    override fun onBind(intent: Intent?): IBinder {
        return binder
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            createNotificationChannels()
        createNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null) {
            val action = intent.getIntExtra(KEY_ACTION_SEND_ACTION_TO_SERVICE, 0)
            if (action != 0) {
                handleActionRecord(action)
            }
            getActionStartCommand(intent)
        }

        return START_STICKY
    }

    override fun onDestroy() {
        stopRecording(false)
        super.onDestroy()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createNotificationChannels() {
        val notificationChannels: MutableList<NotificationChannel> = ArrayList()
        val recordingNotificationChannel = NotificationChannel(
            NOTIFICATION_RECORD_CHANNEL_ID,
            "name",
            NotificationManager.IMPORTANCE_LOW
        )
        recordingNotificationChannel.enableLights(true)
        recordingNotificationChannel.lightColor = Color.RED
        recordingNotificationChannel.setShowBadge(true)
        recordingNotificationChannel.enableVibration(true)
        recordingNotificationChannel.setSound(null, null)

        recordingNotificationChannel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        notificationChannels.add(recordingNotificationChannel)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannels(
            notificationChannels
        )
    }

    private fun createNotification() {
        val isRecordingStatus: Int = if (isRecording) {
            StatusRecord.RECORD_PLAY
        } else {
            StatusRecord.RECORD_PAUSE
        }
        startForeground(
            NOTIFICATION_RECORDING_ID,
            createRecordNotification(isRecordingStatus, mElapsedSeconds)
        )
    }

    private fun startTimer() {
        mTimer?.cancel()
        mTimer = Timer()
        mIncrementTimerTask = object : TimerTask() {
            override fun run() {
                if (isRecording) {
                    mElapsedSeconds++
                    sendAction(ACTION_UPDATE_TIME)
                    createNotification()
                }
            }
        }

        mTimer?.scheduleAtFixedRate(mIncrementTimerTask, 1000, 1000)
    }

    private fun handleActionRecord(action: Int) {
        if (action == ACTION_GET_INFO_FOR_FRAGMENT_RECORDER) {
            sendInfo()
        }
        if (action == ACTION_START_RECORDING) {
            sendAction(ACTION_START_RECORDING)
        }
    }

    private fun sendAction(action: Int) {
        val intent = Intent(KEY_ACTION_SEND_ACTION_TO_FRAGMENT)
        intent.putExtra(KEY_RUNTIME, mElapsedSeconds)
        intent.putExtra(KEY_ACTION, action)
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }

    private fun sendInfo() {
        val intent = Intent(KEY_ACTION_SEND_ACTION_TO_FRAGMENT)
        intent.putExtra(KEY_IS_RECORDING, mElapsedSeconds != 0)
        intent.putExtra(KEY_IS_PAUSE, !isRecording)
        intent.putExtra(KEY_ACTION, Constants.ACTION_GET_INFO_FOR_FRAGMENT_RECORDER)
        intent.putExtra(KEY_RUNTIME, mElapsedSeconds)
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }

    fun resumeRecord() {
        kotlin.runCatching {
            recorder?.resume()
        }
        isRecording = true
        createNotification()

    }

    fun pauseRecord() {
        kotlin.runCatching {
            recorder?.pause()
        }
        isRecording = false
        createNotification()
    }

    fun stopRecording(isSave: Boolean) {
        mElapsedSeconds = 0
        isRecording = false
        kotlin.runCatching {
            recorder?.stop()
            recorder?.release()
            recorder = null
            mTimer?.cancel()
        }
        Handler(Looper.getMainLooper()).postDelayed({ removeNotificationRecorder() }, 500)
        if (isSave) {
            GlobalApp.isSaveAudioSuccess.postValue(true)
        }
    }

    private fun removeNotificationRecorder() {
        stopForeground(true)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(
            NOTIFICATION_RECORDING_ID,
            createRecordNotification(StatusRecord.NO_RECORD, mElapsedSeconds)
        )
    }

    fun startRecord(callback: OnActionCallback) {
        isRecording = true
        configFile(callback)?.let {
            start(it, callback)
        }
        startTimer()
    }

    private fun start(configFile: File, callback: OnActionCallback) {
        kotlin.runCatching {
            recorder = MediaRecorder()
            recorder?.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder?.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder?.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder?.setOutputFile(configFile.getAbsolutePath())
            recorder?.setAudioSamplingRate(DEFAULT_RATE * 1000)
            recorder?.setAudioEncodingBitRate(DEFAULT_BIT_RATE * 1000)
            recorder?.prepare()
            recorder?.start()
        }.onFailure {
            callback.callback(KEY_ERROR, "")
        }
    }

    private fun configFile(callback: OnActionCallback?): File? {
        file = File(BASE_PATH)

        if (file?.exists() == false) {
            file?.mkdir()
        }
        var audioFile =
            File(file?.absolutePath +"/"+ DEFAULT_NAME + System.currentTimeMillis() + "." + AUDIO_EXTENSION)
        var numberical = 1
        while (audioFile.exists()) {
            audioFile =
                File(file?.absolutePath + DEFAULT_NAME + System.currentTimeMillis() + "_" + numberical + "_." + AUDIO_EXTENSION)
            numberical++
        }
        callback?.callback(KEY_NAME_FILE, audioFile.getName())
        file = audioFile
        return file
    }

    private fun getActionStartCommand(intent: Intent) {
        val action = intent.action
        if (null != action && action == ACTION_CLICK_PLAY_PAUSE_NOTIFICATION) {
            if (isRecording) {
                pauseRecord()
            } else {
                resumeRecord()
            }
            sendInfo()
            createNotification()
        }
    }

    fun createRecordNotification(
        statusRecord: Int,
        mElapsedSeconds: Int
    ): Notification {
//        CommonUtils.updateLanguageCurrent(context)
        val notificationLayout = RemoteViews(packageName, R.layout.layout_notification)
        val notificationLayoutBig =
            RemoteViews(packageName, R.layout.layout_notification_big)
        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder: NotificationCompat.Builder =
            NotificationCompat.Builder(this, NOTIFICATION_RECORD_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setCustomContentView(notificationLayout)
                .setCustomBigContentView(notificationLayoutBig)
                .setAutoCancel(false)
                .setShowWhen(false)
                .setOngoing(false)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(null)
                .setStyle(NotificationCompat.DecoratedCustomViewStyle())

        val isRecording = statusRecord != StatusRecord.NO_RECORD
        /*if (isRecording) {
            AppOpenManager.getInstance().disableAppResumeWithActivity(RecordingActivity::class.java)
        } else {
            if (RemoteUtils.isShowAdsResume) {
                AppOpenManager.getInstance().enableAppResume()
            }
        }*/
        setLayoutRecording(notificationLayout, statusRecord, mElapsedSeconds)
        setLayoutRecording(notificationLayoutBig, statusRecord, mElapsedSeconds)

        setPendingIntentLayout(notificationLayout, isRecording)
        setPendingIntentLayout(notificationLayoutBig, isRecording)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId(NOTIFICATION_RECORD_CHANNEL_ID)
            val channel = NotificationChannel(
                NOTIFICATION_RECORD_CHANNEL_ID,
                "VoiceRecorder Notification Default",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }
        val notification = builder.build()
        notification.flags =
            notification.flags or (Notification.FLAG_NO_CLEAR or Notification.FLAG_ONGOING_EVENT)
        return notification
    }

    private fun setPendingIntentLayout(notificationLayoutBig: RemoteViews, isRecording: Boolean) {
        notificationLayoutBig.setOnClickPendingIntent(
            R.id.rlParentLayout,
            getPendingIntent(ActionClickButton.CLICK_RECORD, isRecording)
        )
        notificationLayoutBig.setOnClickPendingIntent(
            R.id.imgRecord,
            getPendingIntent(ActionClickButton.CLICK_RECORD, isRecording)
        )
        notificationLayoutBig.setOnClickPendingIntent(
            R.id.rlParentLayout,
            getPendingIntent(ActionClickButton.CLICK_NOTIFICATION, isRecording)
        )
        notificationLayoutBig.setOnClickPendingIntent(
            R.id.imgSave,
            getPendingIntent(ActionClickButton.CLICK_SAVE, isRecording)
        )
        notificationLayoutBig.setOnClickPendingIntent(
            R.id.imgCancel,
            getPendingIntent(ActionClickButton.CLICK_CANCEL, isRecording)
        )
        notificationLayoutBig.setOnClickPendingIntent(
            R.id.imgPlayPause,
            getPendingIntent(ActionClickButton.CLICK_PLAY_PAUSE, isRecording)
        )
    }

    private fun getPendingIntent(action: Int, isRecording: Boolean): PendingIntent {
        when (action) {

            ActionClickButton.CLICK_RECORD -> {
                return getPendingIntentActivity(Intent(this, RecordActivity::class.java).apply {
                    setAction(ACTION_CLICK_RECORD_NOTIFICATION)
                })
            }

            ActionClickButton.CLICK_CANCEL -> {
                val intent = Intent(this, RecordActivity::class.java).apply {
                    setAction(ACTION_CLICK_CANCEL_NOTIFICATION)
                    putExtra(KEY_ACTION_CLICK_NOTIFICATION, ACTION_CLICK_CANCEL_NOTIFICATION)
                }
                return getPendingIntentActivity(intent)
            }

            ActionClickButton.CLICK_PLAY_PAUSE -> {
                val intent = Intent(this, RecordService::class.java).apply {
                    setAction(ACTION_CLICK_PLAY_PAUSE_NOTIFICATION)
                }
                return getPendingIntentService(intent)
            }

            ActionClickButton.CLICK_SAVE -> {
                val intent = Intent(this, RecordActivity::class.java).apply {
                    setAction(ACTION_CLICK_SAVE_NOTIFICATION)
                    putExtra(KEY_ACTION_CLICK_NOTIFICATION, ACTION_CLICK_SAVE_NOTIFICATION)
                }
                return getPendingIntentActivity(intent)
            }

            else -> {
                val intent = if (isRecording) {
                    Intent(this, RecordActivity::class.java)
                } else {
                    Intent(this, SampleActivity::class.java)
                }
                return getPendingIntentActivity(intent)
            }
        }
    }

    private fun getPendingIntentService(intent: Intent): PendingIntent {
        return PendingIntent.getService(
            this,
            0,
            intent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                PendingIntent.FLAG_MUTABLE
            else
                PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun getPendingIntentActivity(intent: Intent): PendingIntent {
        return PendingIntent.getActivity(
            this,
            0,
            intent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                PendingIntent.FLAG_MUTABLE
            else
                PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun setLayoutRecording(
        notificationLayout: RemoteViews,
        statusRecord: Int,
        mElapsedSeconds: Int
    ) {

        notificationLayout.setTextViewText(
            R.id.tv_time_record,
            mTimerFormat.format(mElapsedSeconds * 1000)
        )
        when (statusRecord) {
            StatusRecord.RECORD_PLAY -> {
                notificationLayout.setViewVisibility(R.id.rlRecording, View.VISIBLE)
                notificationLayout.setViewVisibility(R.id.rlDefault, View.INVISIBLE)
                notificationLayout.setImageViewResource(
                    R.id.imgPlayPause,
                    R.drawable.ic_pause
                )
            }

            StatusRecord.RECORD_PAUSE -> {
                notificationLayout.setViewVisibility(R.id.rlRecording, View.VISIBLE)
                notificationLayout.setViewVisibility(R.id.rlDefault, View.INVISIBLE)
                notificationLayout.setImageViewResource(
                    R.id.imgPlayPause,
                    R.drawable.ic_play
                )
            }

            else -> {
                notificationLayout.setViewVisibility(R.id.rlDefault, View.VISIBLE)
                notificationLayout.setViewVisibility(R.id.rlRecording, View.INVISIBLE)
            }
        }
    }
}

@IntDef(
    StatusRecord.NO_RECORD,
    StatusRecord.RECORD_PAUSE,
    StatusRecord.RECORD_PLAY,
)
annotation class StatusRecord {
    companion object {
        const val NO_RECORD = 0
        const val RECORD_PAUSE = 1
        const val RECORD_PLAY = 2
    }
}

@IntDef(
    ActionClickButton.CLICK_NOTIFICATION,
    ActionClickButton.CLICK_RECORD,
    ActionClickButton.CLICK_FOLDER,
    ActionClickButton.CLICK_CANCEL,
    ActionClickButton.CLICK_PLAY_PAUSE,
    ActionClickButton.CLICK_SAVE
)
annotation class ActionClickButton {
    companion object {
        const val CLICK_NOTIFICATION = 0
        const val CLICK_RECORD = 1
        const val CLICK_FOLDER = 2
        const val CLICK_CANCEL = 3
        const val CLICK_PLAY_PAUSE = 4
        const val CLICK_SAVE = 5
    }
}

interface OnActionCallback {
    fun callback(key: String, data: Any?)
}
