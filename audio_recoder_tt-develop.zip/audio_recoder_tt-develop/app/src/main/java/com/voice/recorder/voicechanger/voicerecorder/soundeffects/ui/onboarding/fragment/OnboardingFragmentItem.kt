package com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.onboarding.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.onboarding.OnboardingActivity
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.onboarding.OnboardingActivity.Companion.ONBOARDING_1
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.onboarding.OnboardingActivity.Companion.ONBOARDING_2
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.onboarding.OnboardingActivity.Companion.ONBOARDING_3
import com.bumptech.glide.Glide
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.R
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.base.BindingFragment
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.data.ConfigPreferences
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.databinding.FragmentOnboardingItemBinding
import com.voice.recorder.voicechanger.voicerecorder.soundeffects.ui.home.MainActivity
import org.koin.android.ext.android.inject

class OnboardingFragmentItem : BindingFragment<FragmentOnboardingItemBinding>() {
    private val configPreferences: ConfigPreferences by inject()
    companion object {
        private const val ID_BACKGROUND = "ID_BACKGROUND"
        private const val TITLE = "TITLE"
        private const val DESCRIPTION = "DESCRIPTION"
        private const val ID_NATIVE = "ID_NATIVE"
        private const val SHOW_NATIVE = "SHOW_NATIVE"
        private const val ID_NATIVE_2_FLOOR = "ID_NATIVE_2_FLOOR"
        private const val SHOW_NATIVE_2_FLOOR = "SHOW_NATIVE_2_FLOOR"
        fun newInstance(
            tag: String,
            @DrawableRes idBackGround: Int,
            @StringRes title: Int?,
            @StringRes description: Int,
            idNative: String,
            isShowNative: Boolean,
            idNative2Floor: String,
            isShowNative2Floor: Boolean,
        ): OnboardingFragmentItem {
            val args = Bundle()
            args.putString("TAG", tag)
            args.putInt(ID_BACKGROUND, idBackGround)
            title?.let { args.putInt(TITLE, it) }
            args.putInt(DESCRIPTION, description)
            args.putString(ID_NATIVE, idNative)
            args.putBoolean(SHOW_NATIVE, isShowNative)
            args.putString(ID_NATIVE_2_FLOOR, idNative2Floor)
            args.putBoolean(SHOW_NATIVE_2_FLOOR, isShowNative2Floor)
            val fragment = OnboardingFragmentItem()
            fragment.arguments = args
            return fragment
        }
    }

    override fun inflateBinding(inflater: LayoutInflater): FragmentOnboardingItemBinding {
        return  FragmentOnboardingItemBinding.inflate(layoutInflater)
    }

    override fun updateUI(view: View, savedInstanceState: Bundle?) {
        binding.swipeAnim.isVisible = false
        binding.txtTutorial.isVisible = false
        binding.txtNext.isVisible = false
        binding.txtNextBG.isVisible = false
        context?.let {
            Glide.with(it).load(arguments?.getInt(ID_BACKGROUND) ?: 0)
                .into(binding.imgOnboarding)
        }
        try {
            arguments?.getInt(TITLE)?.let {
                binding.txtTitle.text = getString(it)
            } ?: run { binding.txtTitle.isVisible = false }
        }catch (e:Exception){
            binding.txtTitle.isVisible = false
        }

        binding.txtDescription.text = getString(arguments?.getInt(DESCRIPTION) ?: 0)

        when (arguments?.getString("TAG")) {
            ONBOARDING_1 -> {
                initViewOnBoarding1()
            }

            ONBOARDING_2 -> {
                initViewOnBoarding2()
            }

            ONBOARDING_3 -> {
                initViewOnBoarding3()
            }
        }
    }

    private fun setDotSelected(
        view: View,
    ) {
        context?.let {
            view.background.setTint(
                ContextCompat.getColor(it, R.color.bg_dots_ob_selected)
            )
        }
    }

    private fun initViewOnBoarding3() {
        binding.txtNextBG.text = getString(R.string.get_started)
        binding.txtNextBG.isVisible = true
        setDotSelected(binding.dotsIndicator.dot3)
        binding.txtNextBG.setOnClickListener {
            configPreferences.isFirstOpen = false
            startActivity(Intent(activity, MainActivity::class.java))
            activity?.finish()
        }
    }

    private fun initViewOnBoarding2() {
        binding.txtNextBG.text = getString(R.string.next)
        binding.swipeAnim.isVisible = true
        binding.txtTutorial.isVisible = true
        binding.txtNextBG.isVisible = true
        setDotSelected(binding.dotsIndicator.dot2)
        binding.txtNextBG.setOnClickListener {
            try {
                (activity as OnboardingActivity)
                    .nextFragment()
            } catch (_: Exception) {
            }
        }
    }

    private fun initViewOnBoarding1() {
        val layoutParams =
            binding.dotsIndicator.root.layoutParams as ConstraintLayout.LayoutParams
        layoutParams.endToEnd = ConstraintLayout.LayoutParams.UNSET
        binding.dotsIndicator.root.layoutParams = layoutParams
        binding.txtNext.isVisible = true
        setDotSelected(binding.dotsIndicator.dot1)
        binding.txtNext.setOnClickListener {
            try {
                (activity as OnboardingActivity)
                    .nextFragment()
            } catch (_: Exception) {
            }
        }
    }
}